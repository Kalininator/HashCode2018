def distance((startx, starty), (finishx, finishy)):
	xdist = abs(finishx - startx)
	ydist = abs(finishy - starty)
	return xdist + ydist